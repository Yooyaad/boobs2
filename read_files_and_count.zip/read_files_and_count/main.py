from collections import Counter

file_path = 'example.txt'
words_list = []

with open(file_path, 'r') as file:
    for line in file:
        words_list.extend(line.split())

word_counts = Counter(words_list)

for word, count in word_counts.items():
    print(f"{word}: {count}")

while True:
    try:
        num = int(input('Write how many words do you want to output: '))
        if num < 1:
            raise ValueError("The integer must be > 0")
        break
    except ValueError as e:
        print(f"Please enter a valid integer greater than 0. Error: {e}")

for word, count in word_counts.most_common(num):
    print(f"{word}: {count}")



































